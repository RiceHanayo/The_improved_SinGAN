import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import sklearn
import sys
import tensorflow as tf
#import time
import cv2
#import glob

# from PIL import Image
# import matplotlib.patches as patch
# import json

from tensorflow import keras
from  tensorflow.compat.v1 import ConfigProto
from  tensorflow.compat.v1 import InteractiveSession
config = ConfigProto()
config.gpu_options.allow_growth = True
session = InteractiveSession(config=config)

from tensorflow.keras.utils import to_categorical
from tensorflow.keras.applications import VGG16, VGG19
from tensorflow.keras.models import load_model
from tensorflow.keras import layers, models

print(tf.__version__)
print(sys.version_info)
for module in mpl,np,pd,sklearn,tf,keras:
    print(module.__name__,module.__version__)

from tensorflow.keras.utils import to_categorical
from tensorflow.keras.applications import VGG16, VGG19,ResNet50,InceptionResNetV2,DenseNet169,MobileNet,DenseNet121
from tensorflow.keras.models import load_model
from tensorflow.keras import layers, models
from tensorflow.compat.v1 import graph_util
from tensorflow.python.keras import backend as K
tf.compat.v1.disable_eager_execution()
K.set_learning_phase(0)

preprocessedFolder = r'.\\Train\\'
testFolder=r'.\\Test\\'
outModelFileName = r'.\\Output\\'
ImageWidth = 128
ImageHeight = 128
ImageNumChannels = 3
# TrainingPercent = 5
ValidationPercent = 10
Batch_Size=8

def read_dl_classifier_data_set(preprocessedFolder):
    img_list = []
    label_list = []
    cnt_class = 0 #存放每个图像的label
    cnt_img = 0
    for directory in os.listdir(preprocessedFolder):
        cnt_class += 1
        tmp_dir = preprocessedFolder + directory
        for image in os.listdir(tmp_dir):
            cnt_img += 1
            tmp_img_filepath = tmp_dir + '/'+image
            tmp_img = cv2.imread(tmp_img_filepath)
            tmp_img = cv2.resize(tmp_img,(ImageWidth, ImageHeight))
            img_list.append(tmp_img)
            label_list.append(cnt_class)
            # tmp_img1 = cv2.rotate(tmp_img, cv2.cv2.ROTATE_90_CLOCKWISE)
            # img_list.append(tmp_img1)
            # label_list.append(cnt_class)
            # tmp_img2 = cv2.flip(tmp_img, 1)
            # img_list.append(tmp_img2)
            # label_list.append(cnt_class)
            if cnt_img % 50 ==0:
                print(str(cnt_img) + " :Load " + tmp_img_filepath + " success!")
    print("Total " + str(cnt_img) + " images read belong to " + str(cnt_class) + "classes" )
    return np.array(img_list),np.array(label_list)

all_train_data,all_train_label = read_dl_classifier_data_set(preprocessedFolder)
all_test_data,all_test_label=read_dl_classifier_data_set(testFolder)
# print(all_train_data)
# print(all_train_label)

# 1、将图像数据像素值压缩至0.0-1.0之间
# 2、对label使用one-hot编码
def preprocess_dl_Image(all_data, all_label):
    all_data = all_data.astype('float32') / 255.

    all_label = to_categorical(all_label)
    return all_data, all_label

all_train_data, all_train_label = preprocess_dl_Image(all_train_data, all_train_label)
all_test_data, all_test_label = preprocess_dl_Image(all_test_data, all_test_label)
print(all_train_data.astype)
print(all_train_label.shape)


# 1、原始数据为有序数据，将数据随机打乱
# 2、训练集：100，验证集：100,测试集=805
def split_dl_classifier_data_set(all_data, all_label, ValidationPercent):
    # 打乱索引
    index = [i for i in range(all_data.shape[0])]
    np.random.shuffle(index)  # 打乱索引
    all_data = all_data[index]
    all_label = all_label[index]
    all_len = all_data.shape[0]

    # train_len = int(all_len * TrainingPercent / 100.)
    validation_len =  int(all_len * ValidationPercent / 100.)
    train_len=all_len-validation_len

    # 切分数据集
    train_data, train_label = all_data[0:train_len, :, :, :], all_label[0:train_len, :]

    val_data, val_label = all_data[train_len:, :, :, :], all_label[train_len:, :]



    return train_data, train_label, val_data, val_label

train_data, train_label, val_data, val_label = split_dl_classifier_data_set(
    all_train_data, all_train_label, ValidationPercent)

test_data,test_label=all_test_data,all_test_label

# print(train_data.shape)
# print(train_data.astype)
# print(train_label.shape)
# print(train_label[0])
# print(val_data.shape)
# print(test_data.shape)

train_dataset=tf.data.Dataset.from_tensor_slices((train_data,train_label))
train_dataset=train_dataset.shuffle(1000).batch(Batch_Size)
val_dataset=tf.data.Dataset.from_tensor_slices((val_data,val_label))
val_dataset=val_dataset.shuffle(1000).batch(Batch_Size)

# print(train_dataset)
# print(val_dataset)


def train_classifier(train_dataset, val_dataset, outModelFileName):
    conv_base = VGG16(weights='imagenet',
                      include_top=False,
                      input_shape=(ImageHeight, ImageWidth, 3)
                      )
    model = models.Sequential()
    model.add(conv_base)
    model.add(layers.Flatten())
    # model.add(layers.Dense(64, activation='relu'))
    # model.add(layers.Dense(32,activation="relu"))
    model.add(layers.Dense(20, activation='softmax'))
    conv_base.trainable = False
    model.compile(loss='categorical_crossentropy',
                  optimizer='adam',
                  metrics=['acc'])

    return model

model = train_classifier(train_dataset, val_dataset, outModelFileName)
model.summary()

# Tensorboard, earlystopping, ModelCheckpoint
logdir = os.path.join('graph_def_and_weights')
if not os.path.exists(logdir):
    os.mkdir(logdir)
#save model
output_model_file = os.path.join(logdir,
                                 "fashion_model.h5")

callbacks = [
    keras.callbacks.TensorBoard(logdir),
    keras.callbacks.ModelCheckpoint(output_model_file,
                                    save_best_only = True,
                                    save_weights_only = False),
    keras.callbacks.EarlyStopping(patience=5, min_delta=1e-3),
]
history = model.fit(train_dataset, epochs=60,
                    validation_data=val_dataset,
                    callbacks = callbacks)

def plot_learning_curves(history):
    pd.DataFrame(history.history).plot(figsize=(8, 5))
    plt.grid(True)
    plt.gca().set_ylim(-0.1,1.2)
    plt.show()

plot_learning_curves(history)


def smooth_curve(points, factor=0.8):
    smoothed_points = []
    for point in points:
        if smoothed_points:
            previous = smoothed_points[-1]
            smoothed_points.append(previous * factor + point * (1 - factor))
        else:
            smoothed_points.append(point)
    return smoothed_points


def plot_history(history):
    acc = history.history['acc']
    val_acc = history.history['val_acc']
    loss = history.history['loss']
    val_loss = history.history['val_loss']
    epochs = range(len(acc))
    plt.plot(epochs,
             smooth_curve(acc), 'bo', label='Smoothed training acc')
    plt.plot(epochs,
             smooth_curve(val_acc), 'b', label='Smoothed validation acc')
    plt.title('Training and validation accuracy')
    plt.legend()

    plt.figure()

    plt.plot(epochs,
             smooth_curve(loss), 'bo', label='Smoothed training loss')
    plt.plot(epochs,
             smooth_curve(val_loss), 'b', label='Smoothed validation loss')
    plt.title('Training and validation loss')
    plt.legend()
    plt.show()

plot_history(history)

test_loss, test_acc = model.evaluate(test_data, test_label)
print(test_loss,test_acc)


def freeze_session(session, keep_var_names=None, output_names=None, clear_devices=True):
    from tensorflow.python.framework.graph_util import convert_variables_to_constants
    graph = session.graph
    with graph.as_default():
        freeze_var_names = list(set(v.op.name for v in tf.compat.v1.global_variables(
        )).difference(keep_var_names or []))
        output_names = output_names or []
        output_names += [v.op.name for v in tf.compat.v1.global_variables()]
        # Graph -> GraphDef ProtoBuf
        input_graph_def = graph.as_graph_def()
        if clear_devices:
            for node in input_graph_def.node:
                node.device = ""
        frozen_graph = convert_variables_to_constants(session, input_graph_def,
                                                      output_names, freeze_var_names)
        return frozen_graph


def WriteDlClassifier(model, outModelFileName):
    # save keras model as *.pb(convert *.h5 to *.pb)
    from tensorflow.compat.v1 import graph_util
    from tensorflow.python.keras import backend as K
    tf.compat.v1.disable_eager_execution()
    K.set_learning_phase(0)
    frozen_graph = freeze_session(tf.compat.v1.keras.backend.get_session(),
                                  output_names=[out.op.name for out in model.outputs],
                                  clear_devices=True)
    tf.io.write_graph(frozen_graph, outModelFileName,
                      'BLclassifier.pb', as_text=False)
    print("save pb successfully! ")

WriteDlClassifier(model, outModelFileName)

'''export the confusion matrix'''
# Y_pred_tta=model.predict_classes(test_data)
# Y_test = [np.argmax(one_hot)for one_hot in test_label]# 由one-hot转换为普通np数组
from sklearn.metrics import classification_report      #分类报告
from sklearn.metrics import confusion_matrix           #混淆矩阵
from sklearn.metrics import accuracy_score             #模型精度
import seaborn as sns

def kappa(confusion_matrix):
    pe_rows = np.sum(confusion_matrix, axis=0)
    pe_cols = np.sum(confusion_matrix, axis=1)
    sum_total = sum(pe_cols)
    pe = np.dot(pe_rows, pe_cols) / float(sum_total ** 2)
    po = np.trace(confusion_matrix) / float(sum_total)
    return (po - pe) / (1 - pe)

classes=['Airport','Beach','Bridge','Commercial','Desert','Farmland','Forest',
 'Industrial' ,'Meadow', 'Mountain' ,'Park' ,'Parking' ,'Pond', 'Port',
 'Residential' ,'River' ,'Viaduct', 'footballField', 'railwayStation']
# classes=['Airport' ,'Beach' ,'Bridge', 'Commercial' ,'Desert' ,'Farmland' ,'Forest',
#  'Industrial', 'Meadow' ,'footballField']
# classes=['Airport' ,'Beach' ,'Bridge' ,'Commercial', 'Desert']


Y_pred_tta=model.predict_classes(test_data)
Y_test = [np.argmax(one_hot)for one_hot in test_label]
print('The report of the result：\n',classification_report(Y_test,Y_pred_tta))
confusion_mc = confusion_matrix(Y_test,Y_pred_tta)#混淆矩阵
df_cm = pd.DataFrame(confusion_mc)
plt.figure(figsize = (34,24))
sns.heatmap(df_cm, annot=True, cmap="BuPu",linewidths=1.0,fmt="d")
plt.title('PipeLine accuracy:{0:.4f},Kappa:{1:.4f}'.format(accuracy_score(Y_test,Y_pred_tta),kappa(confusion_mc)),fontsize=20)
# plt.title('Kappa:{0:.3f}'.format(kappa(confusion_mc)),fontsize=20)
Kappa=kappa(confusion_mc)
print("Kappa:",Kappa)
indices=np.arange(len(classes))
plt.xticks(indices,classes)
plt.yticks(indices,classes)
plt.ylabel('True label',fontsize=20)
plt.xlabel('Predicted label',fontsize=20)
plt.savefig("G:\code\Classification\VGG16\Fixed\Fixed Classifier Accuracy VGG16-1.png")
plt.show()


from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
from sklearn.metrics import roc_curve
from sklearn import metrics
import matplotlib as mpl


y_score = model.predict_proba(test_data)
print ('Calling function：', metrics.roc_auc_score(test_label, y_score, average='micro'))
fpr, tpr, thresholds = metrics.roc_curve(test_label.ravel(),y_score.ravel())
auc = metrics.auc(fpr, tpr)
print('Manual calculation：', auc)
mpl.rcParams['font.sans-serif'] = u'SimHei'
mpl.rcParams['axes.unicode_minus'] = False
plt.figure(figsize = (10,7))
plt.plot(fpr, tpr, c = 'r', lw = 2, alpha = 0.7, label = u'AUC=%.3f' % auc)
plt.plot((0, 1), (0, 1), c = '#808080', lw = 1, ls = '--', alpha = 0.7)
plt.xlim((-0.01, 1.02))
plt.ylim((-0.01, 1.02))
plt.xticks(np.arange(0, 1.1, 0.1))
plt.yticks(np.arange(0, 1.1, 0.1))
plt.xlabel('False Positive Rate', fontsize=16)
plt.ylabel('True Positive Rate', fontsize=16)
plt.grid(b=True, ls=':')
plt.legend(loc='lower right', fancybox=True, framealpha=0.8, fontsize=12)
# plt.savefig("G:\code\Classification\VGG16\Fixed\Fixed ROC VGG16-2.png")
plt.show()
