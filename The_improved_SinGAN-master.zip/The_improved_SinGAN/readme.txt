These codes were written by Songwei Gu.
There are eight documents and nine code files.
The document "SinGAN" includes five code files.
--functions.py
--imresize.py
--manipulate.py
--models.py
--training.py
These are basic modules for the improved smaples.
main_train.py is the console of the improved SinGAN.
config.py includes most hyper-parameters.
random_samples.py is proposed to generate random samples form the given image based on TrainedModels.
classifier.py provides the classifier networks and result reports of them.
The document "Input" is for the training image of the improve SinGAN.
The documents "Train" and "Test" can be adjust for the training datasets and test datasets of classifier.py needly.

The needed python packages includematplotlib,scikit-image,scikit-learn,scipy,numpy,torch,torchvision

The document "Downlaods" includes the experiment data. It is from http://weegee.vision.ucmerced.edu/datasets/landuse.html